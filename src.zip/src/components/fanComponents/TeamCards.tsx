"use client";

import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import TeamDetails from "./TeamDetails";
import type { Team, SortOption } from "@/types/team";

export default function TeamCards() {
  const [teams, setTeams] = useState<Team[]>([]);
  const [filteredTeams, setFilteredTeams] = useState<Team[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortOption, setSortOption] = useState<SortOption>("name-asc");
  const [selectedTeamId, setSelectedTeamId] = useState<string | null>(null);

  useEffect(() => {
    const fetchAllTeams = async () => {
      try {
        setError(null);
        const response = await fetch("/api/teams");
        if (!response.ok) throw new Error(`Failed to fetch teams: ${response.status}`);
        const data = await response.json();

        const teamsArray: Team[] = Array.isArray(data)
          ? data
          : data.teams || data.data || [];

        setTeams(teamsArray);
        setFilteredTeams(teamsArray);
      } catch (err: any) {
        setError(err.message || "Failed to load teams");
      } finally {
        setLoading(false);
      }
    };

    fetchAllTeams();
  }, []);

  useEffect(() => {
    let result = teams;

    if (searchTerm) {
      const lower = searchTerm.toLowerCase();
      result = result.filter(
        (t) =>
          t.team_name.toLowerCase().includes(lower) ||
          (t.coach_id && t.coach_id.toLowerCase().includes(lower)) ||
          (t.players &&
            t.players.some(
              (p) =>
                p.first_name.toLowerCase().includes(lower) ||
                p.last_name.toLowerCase().includes(lower) ||
                p.position.toLowerCase().includes(lower)
            ))
      );
    }

    result = [...result].sort((a, b) => {
      switch (sortOption) {
        case "name-asc":
          return a.team_name.localeCompare(b.team_name);
        case "name-desc":
          return b.team_name.localeCompare(a.team_name);
        case "players-asc":
          return (a.players?.length || 0) - (b.players?.length || 0);
        case "players-desc":
          return (b.players?.length || 0) - (a.players?.length || 0);
        case "coach-asc":
          return (a.coach_id || "").localeCompare(b.coach_id || "");
        case "coach-desc":
          return (b.coach_id || "").localeCompare(a.coach_id || "");
        default:
          return 0;
      }
    });

    setFilteredTeams(result);
  }, [teams, searchTerm, sortOption]);

  const handleTeamClick = (teamId: string) => setSelectedTeamId(teamId);
  const handleBackToList = () => setSelectedTeamId(null);

  if (selectedTeamId) {
    return (
      <div className="relative z-10 min-h-screen">
        <Button
          onClick={handleBackToList}
          variant="outline"
          className="mb-6 bg-white/30 border-gray-300 text-gray-800 hover:bg-white/60"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to All Teams
        </Button>
        <TeamDetails teamId={selectedTeamId} />
      </div>
    );
  }

  if (loading)
    return <div className="text-center text-gray-700 mt-10">Loading teams...</div>;

  if (error)
    return (
      <div className="text-center text-red-500 mt-10">
        <p>{error}</p>
        <Button
          onClick={() => window.location.reload()}
          className="mt-4 bg-orange-500 hover:bg-orange-600 text-white"
        >
          Reload
        </Button>
      </div>
    );

  return (
    <div className="relative z-10">
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-black mb-2">All Teams</h1>
          <p className="text-gray-500">
            Showing {filteredTeams.length} of {teams.length} teams
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredTeams.map((team) => (
            <Card
              key={team.team_id}
              className="cursor-pointer hover:scale-105 transition-all duration-300 bg-black/10 border border-white shadow-lg"
            >
              <CardContent className="p-6 text-center space-y-4">
                {team.icon_url && (
                  <img
                    src={team.icon_url}
                    alt={team.team_name}
                    className="w-24 h-24 object-contain mx-auto rounded-lg bg-white/10 p-2"
                  />
                )}
                <h2 className="text-xl font-semibold text-gray-900">
                  {team.team_name}
                </h2>
                <Button
                  onClick={() => handleTeamClick(team.team_id)}
                  className="w-full bg-orange-500 hover:bg-orange-600 text-white mt-2"
                >
                  View Team Details
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
