"use client"
import Image from "next/image"
import type React from "react"

import { useRouter } from "next/navigation"
import { useAuth } from "@/app/context/AuthContext"
import { supabase } from "../api/DatabaseApi/supabaseClient"
import { CoachSideNav } from "@/components/sideNav/coachSideNav"
import { DashboardHeader } from "@/components/header/header"
import { Reserves } from "@/components/coachComponents/reserves"
import { CourtPlayer } from "@/components/coachComponents/courtPlayer"
import type { Player, CourtPosition } from "@/types/player"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Save } from "lucide-react"

// Mock data for players
const mockPlayers: Player[] = [
  {
    id: "1",
    name: "Deandre Ayton",
    position: "Center",
    jerseyNumber: 5,
    profileImage: "/basketball-player-in-action.png",
    status: "fit",
  },
  {
    id: "2",
    name: "Luka Dončić",
    position: "Forward-Guard",
    jerseyNumber: 77,
    profileImage: "/diverse-basketball-players.png",
    status: "fit",
  },
  {
    id: "3",
    name: "LeBron James",
    position: "Forward",
    jerseyNumber: 23,
    profileImage: "/basketball-player-3.png",
    status: "injured",
  },
  {
    id: "4",
    name: "Dalton Knecht",
    position: "Guard",
    jerseyNumber: 4,
    profileImage: "/diverse-basketball-team.png",
    status: "fit",
  },
  {
    id: "5",
    name: "Austin Reaves",
    position: "Guard",
    jerseyNumber: 15,
    profileImage: "/basketball-player-five.png",
    status: "suspended",
  },
  {
    id: "6",
    name: "Rui Hachimura",
    position: "Forward",
    jerseyNumber: 28,
    profileImage: "/basketball-player-six.png",
    status: "fit",
  },
]

// Predefined court positions
const courtPositions: CourtPosition[] = [
  { id: "pg", x: 50, y: 85, label: "PG" }, // Point Guard
  { id: "sg", x: 25, y: 70, label: "SG" }, // Shooting Guard
  { id: "sf", x: 75, y: 70, label: "SF" }, // Small Forward
  { id: "pf", x: 35, y: 45, label: "PF" }, // Power Forward
  { id: "c", x: 65, y: 45, label: "C" }, // Center
]

export default function CoachDashboard() {
  const router = useRouter()
  const { userName, loading } = useAuth()
  const [activeTab, setActiveTab] = useState("schedule")
  const [reservePlayers, setReservePlayers] = useState<Player[]>(mockPlayers)
  const [courtPlayers, setCourtPlayers] = useState<Map<string, Player>>(new Map())

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push("/")
  }

  const handleStatusChange = (playerId: string, status: Player["status"]) => {
    setReservePlayers((prev) => prev.map((player) => (player.id === playerId ? { ...player, status } : player)))
  }

  const handleAddPlayer = () => {
    console.log("Add player clicked")
    // TODO: Implement add player functionality
  }

  const handleSaveLineup = () => {
    const lineupData = {
      startingLineup: Array.from(courtPlayers.entries()).map(([positionId, player]) => ({
        playerId: player.id,
        playerName: player.name,
        position: positionId.toUpperCase(),
        status: "starting",
      })),
      reserves: reservePlayers.map((player) => ({
        playerId: player.id,
        playerName: player.name,
        status: "reserve",
      })),
    }

    console.log("Team Lineup JSON:", JSON.stringify(lineupData, null, 2))

    const dataStr = JSON.stringify(lineupData, null, 2)
    const dataUri = "data:application/json;charset=utf-8," + encodeURIComponent(dataStr)

    const exportFileDefaultName = `team-lineup-${new Date().toISOString().split("T")[0]}.json`

    const linkElement = document.createElement("a")
    linkElement.setAttribute("href", dataUri)
    linkElement.setAttribute("download", exportFileDefaultName)
    linkElement.click()
  }

  const handleDrop = (e: React.DragEvent, positionId: string) => {
    e.preventDefault()
    const playerData = e.dataTransfer.getData("application/json")
    const droppedPlayer: Player = JSON.parse(playerData)

    // Check if there's already a player at this position
    const existingPlayer = courtPlayers.get(positionId)

    if (existingPlayer) {
      // Swap players: move existing player back to reserves
      setReservePlayers((prev) => [...prev, existingPlayer])
    }

    // Remove player from reserves and add to court
    setReservePlayers((prev) => prev.filter((p) => p.id !== droppedPlayer.id))
    setCourtPlayers((prev) => new Map(prev.set(positionId, droppedPlayer)))
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
  }

  const handleCourtPlayerDragStart = (player: Player) => {
    // Remove player from court when dragging starts
    const positionId = Array.from(courtPlayers.entries()).find(([_, p]) => p.id === player.id)?.[0]

    if (positionId) {
      setCourtPlayers((prev) => {
        const newMap = new Map(prev)
        newMap.delete(positionId)
        return newMap
      })
      setReservePlayers((prev) => [...prev, player])
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <div className="text-orange-500 text-xl">Loading...</div>
      </div>
    )
  }

  const renderTabContent = () => {
    switch (activeTab) {
      case "schedule":
        return (
          <div className="max-w-6xl mx-auto p-6">
            <div className="bg-black/50 backdrop-blur-sm border border-orange-500/20 rounded-lg p-8 text-center">
              <h2 className="text-2xl font-bold text-white mb-4">Team Schedule</h2>
              <p className="text-gray-300">This is where the team schedule and upcoming games will be displayed</p>
            </div>
          </div>
        )
      case "all-games":
        return (
          <div className="max-w-6xl mx-auto p-6">
            <div className="bg-black/50 backdrop-blur-sm border border-orange-500/20 rounded-lg p-8 text-center">
              <h2 className="text-2xl font-bold text-white mb-4">All Games</h2>
              <p className="text-gray-300">This is where all past and future games will be displayed</p>
            </div>
          </div>
        )
      case "team-management":
        return (
          <div className="max-w-full mx-auto p-6">
            <div className="mb-6 flex justify-between items-center">
              <h1 className="text-3xl font-bold text-white">Team Management</h1>
              <Button
                onClick={handleSaveLineup}
                className="flex items-center gap-2 bg-orange-500 hover:bg-orange-600 text-white"
              >
                <Save className="w-4 h-4" />
                Save Lineup
              </Button>
            </div>

            <div className="flex gap-6 h-[calc(130vh-160px)]">
              {/* Basketball Court - 70% */}
              <div className="flex-[7] relative">
                <Card className="h-full overflow-hidden bg-black/50 backdrop-blur-sm border-orange-500/20">
                  <CardContent className="p-0 h-full relative">
                    <div
                      className="w-full h-full bg-cover bg-center bg-no-repeat relative"
                      style={{
                        backgroundImage: `url('/court/aerialView.png')`,
                      }}
                    >
                      <div className="absolute inset-0 bg-black/20"></div>

                      {/* Drop Zones for Court Positions */}
                      {courtPositions.map((position) => (
                        <div key={position.id}>
                          {/* Drop Zone */}
                          <div
                            className="absolute w-16 h-16 border-2 border-dashed border-orange-500/50 rounded-full bg-orange-500/10 hover:bg-orange-500/20 transition-colors z-10"
                            style={{
                              left: `${position.x}%`,
                              top: `${position.y}%`,
                              transform: "translate(-50%, -50%)",
                            }}
                            onDrop={(e) => handleDrop(e, position.id)}
                            onDragOver={handleDragOver}
                          />

                          <div
                            className="absolute text-white font-bold text-sm bg-black/80 px-2 py-1 rounded z-30 pointer-events-none"
                            style={{
                              left: `${position.x}%`,
                              top: `${position.y + 8}%`,
                              transform: "translate(-50%, -50%)",
                            }}
                          >
                            {position.label}
                          </div>
                        </div>
                      ))}

                      {/* Players on Court */}
                      {courtPositions.map((position) => {
                        const player = courtPlayers.get(position.id)
                        return player ? (
                          <CourtPlayer
                            key={`${position.id}-${player.id}`}
                            player={player}
                            position={{ x: position.x, y: position.y }}
                            onDragStart={handleCourtPlayerDragStart}
                          />
                        ) : null
                      })}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Reserves Section - 30% */}
              <div className="flex-[3] h-full">
                <Reserves players={reservePlayers} onAddPlayer={handleAddPlayer} onStatusChange={handleStatusChange} />
              </div>
            </div>
          </div>
        )
      case "team-stats":
        return (
          <div className="max-w-6xl mx-auto p-6">
            <div className="bg-black/50 backdrop-blur-sm border border-orange-500/20 rounded-lg p-8 text-center">
              <h2 className="text-2xl font-bold text-white mb-4">Team Statistics</h2>
              <p className="text-gray-300">
                This is where comprehensive team statistics and performance metrics will be shown
              </p>
            </div>
          </div>
        )
      case "players":
        return (
          <div className="max-w-6xl mx-auto p-6">
            <div className="bg-black/50 backdrop-blur-sm border border-orange-500/20 rounded-lg p-8 text-center">
              <h2 className="text-2xl font-bold text-white mb-4">Team Players</h2>
              <p className="text-gray-300">This is where player roster and individual statistics will be managed</p>
            </div>
          </div>
        )
      default:
        return null
    }
  }

  return (
    <div className="relative min-h-screen">
      <CoachSideNav activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Background image */}
      <div className="fixed inset-0 z-0">
        <Image src="/bgr.jpg" alt="Background" fill priority className="object-cover" />
      </div>

      {/* Main content */}
      <div className="relative z-10 min-h-screen bg-black/30 backdrop-blur-sm">
        <DashboardHeader placeholder="Search players and teams..." />

        {renderTabContent()}
      </div>
    </div>
  )
}
