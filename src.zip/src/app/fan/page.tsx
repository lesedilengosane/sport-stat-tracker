"use client"
import Image from "next/image"
import { useState } from "react"
import { DashboardHeader } from "@/components/header/header"
import { FanSideNav } from "@/components/sideNav/fanSideNav"
import { SeasonHighlights } from "@/components/fanComponents/SeasonHighlights"
import { TopScorers } from "@/components/fanComponents/TopScorers"
import { GameSchedule } from "@/components/fanComponents/GameSchedule"
import { LeagueStandings } from "@/components/fanComponents/leagueStanding"
import { PlayerCards } from "@/components/fanComponents/PlayerCards"

export default function FanDashboard() {
  const [activeTab, setActiveTab] = useState("overview")

  const renderOverview = () => (
    <div className="max-w-7xl mx-auto p-6 space-y-8">
      <SeasonHighlights />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <GameSchedule compact />
        <TopScorers />
      </div>

      <LeagueStandings compact />
    </div>
  )

  const renderPlayers = () => (
    <div className="max-w-7xl mx-auto p-6">
      <PlayerCards />
    </div>
  )

  const renderSchedule = () => (
    <div className="max-w-7xl mx-auto p-6">
      <GameSchedule />
    </div>
  )

  const renderStandings = () => (
    <div className="max-w-7xl mx-auto p-6">
      <LeagueStandings />
    </div>
  )

  const renderTabContent = () => {
    switch (activeTab) {
      case "overview":
        return renderOverview()
      case "players":
        return renderPlayers()
      case "schedule":
        return renderSchedule()
      case "standings":
        return renderStandings()
      default:
        return renderOverview()
    }
  }

  return (
    <div className="relative min-h-screen">
      <FanSideNav activeTab={activeTab} onTabChange={setActiveTab} />

      <div className="fixed inset-0 z-0">
        <Image src="/bgr.jpg" alt="Background" fill priority className="object-cover" />
        <div className="absolute inset-0 bg-white/40 backdrop-blur-lg" />
      </div>

      {/* Main content */}
      <div className="relative z-10 min-h-screen">
        <div className="sticky top-0 z-20 bg-transparent">
          <DashboardHeader placeholder="Search players and teams..." />
        </div>

        {renderTabContent()}
      </div>
    </div>
  )
}
