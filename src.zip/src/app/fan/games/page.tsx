"use client"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { useEffect, useRef, useState } from "react"

import { GamesGrid } from "@/components/games-grid"

import { GameCardSkeleton } from "@/components/Loading-Card/game-card-skeleton"
import { useAuth } from "@/app/context/AuthContext"
import { AnalystSideNav } from "@/components/sideNav/analystSideNav"
import { DashboardHeader } from "@/components/header/header"
import { CompletedGamesGrid } from "@/components/completed-games-grid"
import { Game,Match } from "@/types/basketball"
import { useMatches } from "@/app/context/MatchesContext"
import PlayerInsightsPanel from "@/components/playerinsight"
import { CoachGamesGrid } from "@/components/coach-games-grid"


// Define TypeScript interfaces based on your schema
interface Team {
  team_id: string
  name: string
  icon_url: string
}

interface Player {
  player_id: string
  position: string
  player: string
  jerseyNumber?: number
}



const convertToPlayerDetails = (lineup: any[], team: "home" | "away") => {
  return lineup.map((player, index) => {
    const nameParts = player.player?.split(" ") || ["Player", "Unknown"]
    const name = nameParts[0] || "Player"
    // The Player interface does not require surname, so omit it
    return {
      player_id: player.player_id || `${team}-player-${index}`,
      name,
      position: player.position || "Unknown",
      // jerseyNumber is optional and can be added if available
      jerseyNumber: player.jerseyNumber,
    }
  })
}

export default function FanGames() {
  const router = useRouter()


    const { 
    allGames, 
    matches, 
    isLoading, 
    error,
    triggerRefetch
  } = useMatches(); // ✅ get everything from context

  const [activeTab, setActiveTab] = useState("upcoming-games");
  const { user } = useAuth();

  





  const upcomingGames = allGames
  .filter(game => !game.completed)
  .sort((a, b) => {
    const dateA = new Date(`${a.date} ${a.time}`);
    const dateB = new Date(`${b.date} ${b.time}`);
    return dateA.getTime() - dateB.getTime(); // ascending order (earliest first)
  });//future games
const completedGames = allGames.filter(
  (game) => game.completed === true);//games that have been played

// Booked (upcoming) games for this analyst



  

  return (

    <div>
        <div>
            <h1>Completed games with their History</h1>
            <div className="max-w-6xl mx-auto p-6">
            <CoachGamesGrid
              games={completedGames.map((game) => ({
                ...game,
                homeLineup: convertToPlayerDetails(game.homeLineup || [], "home"),
                awayLineup: convertToPlayerDetails(game.awayLineup || [], "away"),
              }))}
            />
          </div>


            
        </div>
        <div>
            <h1>Unplayed games or upcoming games sorted by date</h1>
            <CoachGamesGrid
              games={upcomingGames.map((game) => ({
                ...game,
                homeLineup: convertToPlayerDetails(game.homeLineup || [], "home"),
                awayLineup: convertToPlayerDetails(game.awayLineup || [], "away"),
              }))}
            />
        </div>

    </div>
    

  )

}