export interface Player {
    id: string
    name: string
    position: string
    jerseyNumber: number
    profileImage: string
    status: "fit" | "injured" | "suspended"
  }
  
  export interface CourtPosition {
    id: string
    x: number
    y: number
    label: string
    player?: Player
  }
  